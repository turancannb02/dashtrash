"""
dashtrash - Terminal-based dashboard for real-time monitoring
"""

__version__ = "0.1.0"
__author__ = "dashtrash contributors" 